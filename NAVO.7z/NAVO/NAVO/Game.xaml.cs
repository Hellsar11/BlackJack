﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NAVO
{
    /// <summary>
    /// Логика взаимодействия для Game.xaml
    /// </summary>
    public partial class Game : Window
    {
        int StMoney = 0;
        int BalanceMoney = 0;
        int playerScore = 0;
        int krupScore = 0;
        int countClick = 0;
        MainMenu mm = new MainMenu();
        List<Image> cards = new List<Image>();
        List<Image> krupSlotsCollection = new List<Image>();

        public Game()
        {
            InitializeComponent();
            cards.Add(TuzB11);
            cards.Add(B2);
            cards.Add(B3);
            cards.Add(B4);
            cards.Add(B5);
            cards.Add(B6);
            cards.Add(B7);
            cards.Add(B8);
            cards.Add(B9);
            cards.Add(B10);
            cards.Add(ValB10);
            cards.Add(QueenB10);
            cards.Add(KingB10);
            cards.Add(TuzS11);
            cards.Add(S2);
            cards.Add(S3);
            cards.Add(S4);
            cards.Add(S5);
            cards.Add(S6);
            cards.Add(S7);
            cards.Add(S8);
            cards.Add(S9);
            cards.Add(S10);
            cards.Add(ValS10);
            cards.Add(QueenS10);
            cards.Add(KingS10);
            cards.Add(TuzP11);
            cards.Add(P2);
            cards.Add(P3);
            cards.Add(P4);
            cards.Add(P5);
            cards.Add(P6);
            cards.Add(P7);
            cards.Add(P8);
            cards.Add(P9);
            cards.Add(P10);
            cards.Add(ValP10);
            cards.Add(QueenP10);
            cards.Add(KingP10);
            cards.Add(TuzT11);
            cards.Add(T2);
            cards.Add(T3);
            cards.Add(T4);
            cards.Add(T5);
            cards.Add(T6);
            cards.Add(T7);
            cards.Add(T8);
            cards.Add(T9);
            cards.Add(T10);
            cards.Add(ValT10);
            cards.Add(QueenT10);
            cards.Add(KingT10);
            krupSlotsCollection.Add(KrupSlot2);
            krupSlotsCollection.Add(KrupSlot3);
            krupSlotsCollection.Add(KrupSlot4);
            krupSlotsCollection.Add(KrupSlot5);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var text = " ";
            using (StreamReader sr = new StreamReader(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt"))
            {
                text = sr.ReadToEnd();
               
                    BalanceMoney = Convert.ToInt32(text);
                    Balance.Text = BalanceMoney.ToString();
                
            }
            if (Convert.ToInt32(text) == 0)
            {
                using (StreamWriter sw = new StreamWriter(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt"))
                {
                    int x = 150;
                    sw.Write(x);
                    BalanceMoney = x;
                    Balance.Text = BalanceMoney.ToString();
                }


            }
        }

        private void HitBtn_Click(object sender, RoutedEventArgs e)
        {
            ButtonsOnOff();
            Random rand = new Random();

            var cardKrup = cards[rand.Next(0, cards.Count() - 1)];
            var playerCard1 = cards[rand.Next(0, cards.Count() - 1)];
            var playerCard2 = cards[rand.Next(0, cards.Count() - 1)];
            cards.Remove(cardKrup);
            cards.Remove(playerCard1);
            cards.Remove(playerCard2);

            KrupSlot1.Source = cardKrup.Source;
            PlayerSlot1.Source = playerCard1.Source;
            PlayerSlot2.Source = playerCard2.Source;

            var scoreCount1 = playerCard1.Name.Where(x => char.IsDigit(x)).Count();
            var scoreCount2 = playerCard2.Name.Where(x => char.IsDigit(x)).Count();

            if (scoreCount1 == 1)
            {
                string s = playerCard1.Name[playerCard1.Name.Length - 1].ToString();
                playerScore += Convert.ToInt32(s);
            }
            else
            {
                string s = playerCard1.Name[playerCard1.Name.Length - 2].ToString() + playerCard1.Name[playerCard1.Name.Length - 1].ToString();
                playerScore += Convert.ToInt32(s);
            }

            if (scoreCount2 == 1)
            {
                string s = playerCard2.Name[playerCard2.Name.Length - 1].ToString();
                playerScore += Convert.ToInt32(s);
            }
            else
            {
                string s = playerCard2.Name[playerCard2.Name.Length - 2].ToString() + playerCard2.Name[playerCard2.Name.Length - 1].ToString();
                playerScore += Convert.ToInt32(s);
            }
            PlayerScore.Text = playerScore.ToString();
            foreach (var cardKr in cardKrup.Name)
            {
                if (char.IsDigit(cardKr))
                {
                    KrupScore.Text += cardKr.ToString();
                }
            }
            krupScore = Convert.ToInt32(KrupScore.Text);
            if (playerScore == 21)
            {
                Game mm = new Game();
                MessageBox.Show("BlackJack!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                mm.Show();
                this.Close();
            }


        }

        public void ButtonsOnOff()
        {
            TakeBtn.Visibility = Visibility.Visible;
            SkipBtn.Visibility = Visibility.Visible;
            PlusBtn.Visibility = Visibility.Hidden;
            MinusBtn.Visibility = Visibility.Hidden;
            HitBtn.Visibility = Visibility.Hidden;
        }

        private void PlusBtn_Click(object sender, RoutedEventArgs e)
        {
            if (Convert.ToInt32(Balance.Text) <= 0)
            {
                MessageBox.Show("Недостаточно средств!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                StMoney += 5;
                BalanceMoney -= 5;
                StavkaMoney.Text = StMoney.ToString();
                Balance.Text = BalanceMoney.ToString();
            }

        }

        private void MinusBtn_Click(object sender, RoutedEventArgs e)
        {
            if (Convert.ToInt32(StavkaMoney.Text) <= 0)
            {
                MessageBox.Show("Повысьте ставку!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                StMoney -= 5;
                BalanceMoney += 5;
                StavkaMoney.Text = StMoney.ToString();
                Balance.Text = BalanceMoney.ToString();
            }

        }

        private void TakeBtn_Click(object sender, RoutedEventArgs e)
        {
            countClick++;
            switch (countClick)
            {
                case 1:
                    Random rand = new Random();
                    var cardPlayer = cards[0];
                    PlayerSlot3.Source = cardPlayer.Source;
                    cards.Remove(cardPlayer);
                    var scoreCount = cardPlayer.Name.Where(x => char.IsDigit(x)).Count();
                    if (scoreCount == 1)
                    {
                        string s = cardPlayer.Name[cardPlayer.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    else if (scoreCount == 2 && playerScore >= 11 && cardPlayer.Name.Contains("Tuz"))
                    {
                        string s = cardPlayer.Name[cardPlayer.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    else if (scoreCount == 2)
                    {
                        string s = cardPlayer.Name[cardPlayer.Name.Length - 2].ToString() + cardPlayer.Name[cardPlayer.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    PlayerScore.Text = playerScore.ToString();
                    break;
                case 2:
                    Random rand2 = new Random();
                    var cardPlayer2 = cards[rand2.Next(0, cards.Count() - 1)];
                    PlayerSlot4.Source = cardPlayer2.Source;
                    cards.Remove(cardPlayer2);
                    var scoreCount2 = cardPlayer2.Name.Where(x => char.IsDigit(x)).Count();
                    if (scoreCount2 == 1)
                    {
                        string s = cardPlayer2.Name[cardPlayer2.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    else if (scoreCount2 == 2 && playerScore >= 11 && cardPlayer2.Name.Contains("Tuz"))
                    {
                        string s = cardPlayer2.Name[cardPlayer2.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    else if (scoreCount2 == 2)
                    {
                        string s = cardPlayer2.Name[cardPlayer2.Name.Length - 2].ToString() + cardPlayer2.Name[cardPlayer2.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    PlayerScore.Text = playerScore.ToString();
                    break;
                case 3:
                    Random rand3 = new Random();
                    var cardPlayer3 = cards[rand3.Next(0, cards.Count() - 1)];
                    PlayerSlot5.Source = cardPlayer3.Source;
                    cards.Remove(cardPlayer3);
                    var scoreCount3 = cardPlayer3.Name.Where(x => char.IsDigit(x)).Count();
                    if (scoreCount3 == 1)
                    {
                        string s = cardPlayer3.Name[cardPlayer3.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    else if (scoreCount3 == 2 && playerScore >= 11 && cardPlayer3.Name.Contains("Tuz"))
                    {
                        string s = cardPlayer3.Name[cardPlayer3.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    else if (scoreCount3 == 2)
                    {
                        string s = cardPlayer3.Name[cardPlayer3.Name.Length - 2].ToString() + cardPlayer3.Name[cardPlayer3.Name.Length - 1].ToString();
                        playerScore += Convert.ToInt32(s);
                    }
                    PlayerScore.Text = playerScore.ToString();
                    break;
            }

            if (playerScore > 21)
            {
                Game mm = new Game();
                MessageBox.Show("Вы проиграли!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                using (StreamWriter sw = new StreamWriter(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt", false, System.Text.Encoding.Default))
                {
                    sw.WriteLine(Balance.Text);
                }
                mm.Show();
                this.Close();
            }
            else if (playerScore == 21)
            {
                Game mm = new Game();
                MessageBox.Show("Победа!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                using (StreamWriter sw = new StreamWriter(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt", false, System.Text.Encoding.Default))
                {
                    int money = BalanceMoney + (StMoney*2);
                    sw.WriteLine(money);
                }
                mm.Show();
                this.Close();
            }
        }

        private void SkipBtn_Click(object sender, RoutedEventArgs e)
        {         
            int i = 0;
            while (krupScore <= playerScore && krupScore != playerScore)
            {
                Random rand = new Random();
                var cardKrup = cards[rand.Next(0, cards.Count() - 1)];
                krupSlotsCollection[i].Source = cardKrup.Source;
                cards.Remove(cardKrup);
                var scoreCount = cardKrup.Name.Where(x => char.IsDigit(x)).Count();
                if (scoreCount == 1)
                {
                    string s = cardKrup.Name[cardKrup.Name.Length - 1].ToString();
                    krupScore += Convert.ToInt32(s);
                }
                else if (scoreCount == 2 && krupScore >= 11 && cardKrup.Name.Contains("Tuz"))
                {
                    string s = cardKrup.Name[cardKrup.Name.Length - 1].ToString();
                    krupScore += Convert.ToInt32(s);
                }
                else if (scoreCount == 2)
                {
                    string s = cardKrup.Name[cardKrup.Name.Length - 2].ToString() + cardKrup.Name[cardKrup.Name.Length - 1].ToString();
                    krupScore += Convert.ToInt32(s);
                }
                KrupScore.Text = krupScore.ToString();

                if (krupScore > 21)
                {
                    Game mm = new Game();
                    MessageBox.Show("Вы победили!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                    using (StreamWriter sw = new StreamWriter(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt", false, System.Text.Encoding.Default))
                    {
                        int money = BalanceMoney + (StMoney * 2);
                        sw.WriteLine(money);
                    }
                    mm.Show();
                    this.Close();
                }
                else if (krupScore == 21)
                {
                    Game mm = new Game();
                    MessageBox.Show("Вы проиграли!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                    using (StreamWriter sw = new StreamWriter(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt", false, System.Text.Encoding.Default))
                    {
                        sw.WriteLine(Balance.Text);
                    }
                    mm.Show();
                    this.Close();
                }
                else if (krupScore > playerScore)
                {
                    Game mm = new Game();
                    MessageBox.Show("Вы проиграли!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                    using (StreamWriter sw = new StreamWriter(@"C:\Users\NewUser.DESKTOP-08\Downloads\NAVO\NAVO\Score.txt", false, System.Text.Encoding.Default))
                    {
                        sw.WriteLine(Balance.Text);
                    }
                    mm.Show();
                    this.Close();
                }
                else if (krupScore == playerScore)
                {
                    Game mm = new Game();
                    MessageBox.Show("Ничья!", "Администрация NAVO", MessageBoxButton.OK, MessageBoxImage.Information);
                    mm.Show();
                    this.Close();
                }
                i++;

            }
        }
    }
}
